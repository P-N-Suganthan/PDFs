# Supplementary Material

### A Novel Approach for Training Deep Neural Network Using Multiple Output Heads and Boosting
*Accepted at the International Joint Conference on Neural Networks (IJCNN 2026)*

---

This page provides additional experimental details and hyperparameter settings supporting the results reported in the paper.

---

## Datasets

The table below summarizes the tabular and vision datasets used in the experiments.

### Tabular Datasets (UCI Repository)

| Dataset | Samples | Features | Classes | Discipline |
|---|---|---|---|---|
| chess-krvkp | 3,196 | 36 | 2 | Gaming/Chess |
| cardiotocography-10clases | 2,126 | 21 | 10 | Medicine/Obstetrics |
| breast-cancer-wisc-prog | 198 | 33 | 2 | Medicine/Oncology |
| breast-tissue | 106 | 9 | 6 | Medicine/Oncology |
| synthetic-control | 600 | 60 | 6 | Statistics/Data Mining |
| oocytes\_trisopterus\_states\_5b | 912 | 32 | 3 | Biology/Reproductive Science |
| ionosphere | 351 | 33 | 2 | Space Science/Radar |
| iris | 150 | 4 | 3 | Botany |
| contrac | 1,473 | 9 | 3 | Healthcare/Contraception |
| seeds | 210 | 7 | 3 | Agriculture/Botany |

### Vision Datasets

| Dataset | Images | Classes | Discipline |
|---|---|---|---|
| CUB-200-2011 (Birds) | 11,788 | 200 | Fine-grained Recognition |
| Caltech-101 | 9,144 | 102 | Object Recognition |
| Stanford Dogs | 20,580 | 120 | Fine-grained Recognition |
| Oxford 102 Flowers | 8,189 | 102 | Fine-grained Recognition |

---

## Hyperparameter Tuning

For each model, hyperparameters were optimized using SMAC with a budget of 50 trials per model. The table below reports the tuned hyperparameters and corresponding search ranges used across all experiments.

### Backbone Training

| Hyperparameter | Search Range |
|---|---|
| Learning rate | {1e-5, 3e-5, 5e-5, 1e-4, 3e-4} |
| Weight decay | {0.0, 0.01, 0.03, 0.05} |
| Batch size | {8, 16, 32} |
| Warmup ratio | {0.0, 0.05, 0.1} |
| LR scheduler | {cosine, linear, cosine-restarts} |

### Output Head

| Hyperparameter | Search Range |
|---|---|
| Learning rate | [1e-4, 1e-2] (log-scale) |
| ℓ₁ regularization | [1e-8, 1e-3] (log-scale) |
| ℓ₂ regularization | [1e-6, 1e-2] (log-scale) |

### Gradient RFRBoost

| Hyperparameter | Search Range |
|---|---|
| Number of boosting layers (`n_layers`) | [1, 10] (log-scale integer) |
| Hidden dimension (`d_hidden`) | [16, 512] (log-scale integer) |
| Boosting step size (η) | [0.1, 1.0] (log-scale) |
| Classifier ℓ₂ regularization (λ_cls) | [1e-5, 10] (log-scale) |
| Gradient ℓ₂ regularization (λ_ĝ) | [1e-5, 10] (log-scale) |
| SWIM feature scale | [0.25, 2.0] |

### MO-MLP

| Hyperparameter | Search Range |
|---|---|
| Number of layers (`n_layers`) | [1, 15] (integer) |
| Hidden units per layer (`n_nodes`) | [256, 1024] (integer) |
| Learning rate | [1e-5, 1e-1] (log-scale) |
| Batch percentage | [0.05, 0.5] |
| ℓ₁ regularization | [1e-7, 1e-2] (log-scale) |
| ℓ₂ regularization | [1e-7, 4×10³] (log-scale) |
| CFS ℓ₂ regularization | [1e-7, 4×10³] (log-scale) |
| Dropout probability (`p_drop`) | [0, 0.5] |

### edRVFL

| Hyperparameter | Search Range |
|---|---|
| Number of layers (`n_layers`) | [1, 15] (integer) |
| Hidden units per layer (`n_nodes`) | [256, 1024] (integer) |
| CFS ℓ₂ regularization | [1e-7, 4×10³] (log-scale) |
